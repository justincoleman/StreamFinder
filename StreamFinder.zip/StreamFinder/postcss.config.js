// NEW postcss.config.js
export default {
  plugins: {
    '@tailwindcss/postcss': {}, // Use the new package name here
    autoprefixer: {},
  },
}