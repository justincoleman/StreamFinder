// src/stores/streamingStore.js
import { defineStore } from 'pinia';
import allServicesData from '@/data/streamingServicesData.json';
import leaguesData from '@/data/leagues.json';

// Helper function to parse price string to a number
function parsePrice(priceString) {
  if (!priceString || typeof priceString !== 'string') {
    return Infinity;
  }
  const match = priceString.match(/[\d\.]+/);
  return match ? parseFloat(match[0]) : Infinity;
}

// Helper to calculate unique covered leagues for a set of services
function getBundleCoverageDetails(servicesInBundle, selectedLeagueIds, allLeaguesFlat) {
  const coveredLeaguesSet = new Set();
  const coveredLeaguesDetails = {};

  servicesInBundle.forEach(service => {
    selectedLeagueIds.forEach(leagueId => {
      if (service.leagues && service.leagues[leagueId]) {
        coveredLeaguesSet.add(leagueId);
        const leagueInfo = allLeaguesFlat.find(l => l.id === leagueId);
        if (!coveredLeaguesDetails[leagueId]) {
          coveredLeaguesDetails[leagueId] = {
            name: leagueInfo ? leagueInfo.name : leagueId,
            icon: leagueInfo ? leagueInfo.icon : '?',
            channels: [],
          };
        }
        const serviceChannels = service.leagues[leagueId].channels.map(ch => `${ch} (on ${service.name})`);
        coveredLeaguesDetails[leagueId].channels = [...new Set([...(coveredLeaguesDetails[leagueId].channels || []), ...serviceChannels])];
      }
    });
  });
  return { count: coveredLeaguesSet.size, details: coveredLeaguesDetails };
}

export const useStreamingStore = defineStore('streaming', {
  state: () => ({
    allLeaguesByCategory: leaguesData,
    allAvailableServices: allServicesData,
    selectedLeagueIds: [],
    subscribedServiceIds: [],
    expandedCategories: [],
    expandedServiceCategories: [],
  }),

  getters: {
    allLeaguesFlat(state) {
      return state.allLeaguesByCategory.reduce((acc, category) => acc.concat(category.leagues), []);
    },

    allServicesGroupedByCategory(state) {
        const grouped = {};
        if (!Array.isArray(state.allAvailableServices)) {
            return [];
        }
        state.allAvailableServices.forEach(service => {
            const category = service.serviceCategory || 'Other';
            if (!grouped[category]) {
                grouped[category] = {
                    categoryName: category,
                    icon: category === 'Live TV Streaming' ? '📺' : (category === 'League/Sport Specific' ? '🎯' : (category === 'Sport Specific & Add-ons' ? '➕' : '📦')),
                    services: []
                };
            }
            grouped[category].services.push(service);
        });
        const result = Object.values(grouped).sort((a,b) => a.categoryName.localeCompare(b.categoryName));
        return result;
    },

    processedAvailableServicesFlat(state) {
        if (!Array.isArray(state.allAvailableServices)) {
            return [];
        }
        return state.allAvailableServices.map(s => ({
            ...s,
            numericPrice: parsePrice(s.price),
            isSubscribed: state.subscribedServiceIds.includes(s.id),
        }));
    },

    selectedLeagues(state) {
      return this.allLeaguesFlat.filter(league => state.selectedLeagueIds.includes(league.id));
    },

    subscribedServicesDetails(state) {
      return this.processedAvailableServicesFlat.filter(service => service.isSubscribed);
    },

    getFilteredServices(state) {
      if (state.selectedLeagueIds.length === 0) {
        return [];
      }
      const allLeaguesFlatForHelper = this.allLeaguesFlat;
      const currentProcessedAvailableServices = this.processedAvailableServicesFlat;

      const userSubscribedServices = currentProcessedAvailableServices.filter(s => s.isSubscribed);
      const nonSubscribedServices = currentProcessedAvailableServices.filter(s => !s.isSubscribed);

      const baseCoverageFromSubscribed = getBundleCoverageDetails(userSubscribedServices, state.selectedLeagueIds, allLeaguesFlatForHelper);
      const baseCoveredLeagueIds = new Set(Object.keys(baseCoverageFromSubscribed.details));

      let allCandidateItems = [];
      allCandidateItems.push({
        idSuffix: 'subscribed_only', servicesInvolved: [...userSubscribedServices], additionalNumericCost: 0,
      });
      nonSubscribedServices.forEach(ns1 => {
        allCandidateItems.push({
          idSuffix: `plus_${ns1.id}`, servicesInvolved: [...userSubscribedServices, ns1], additionalNumericCost: ns1.numericPrice,
        });
      });
      if (nonSubscribedServices.length >= 2) {
        for (let i = 0; i < nonSubscribedServices.length; i++) {
          for (let j = i + 1; j < nonSubscribedServices.length; j++) {
            const ns1 = nonSubscribedServices[i]; const ns2 = nonSubscribedServices[j];
            allCandidateItems.push({
              idSuffix: `plus_${ns1.id}_${ns2.id}`, servicesInvolved: [...userSubscribedServices, ns1, ns2], additionalNumericCost: ns1.numericPrice + ns2.numericPrice,
            });
          }
        }
      }
      currentProcessedAvailableServices.forEach(service => {
          allCandidateItems.push({
              idSuffix: `single_${service.id}`, servicesInvolved: [service],
              additionalNumericCost: service.isSubscribed ? 0 : service.numericPrice,
          });
      });
      if (currentProcessedAvailableServices.length >= 2) {
        for (let i = 0; i < currentProcessedAvailableServices.length; i++) {
          for (let j = i + 1; j < currentProcessedAvailableServices.length; j++) {
            const s1 = currentProcessedAvailableServices[i]; const s2 = currentProcessedAvailableServices[j];
            const servicesInBundle = [s1, s2];
            let additionalCost = 0;
            if (!s1.isSubscribed) additionalCost += s1.numericPrice;
            if (!s2.isSubscribed) additionalCost += s2.numericPrice;
            allCandidateItems.push({
              idSuffix: `pair_${s1.id}_${s2.id}`, servicesInvolved: servicesInBundle, additionalNumericCost: additionalCost
            });
          }
        }
      }
       if (currentProcessedAvailableServices.length >=3) {
          for (let i = 0; i < currentProcessedAvailableServices.length; i++) {
              for (let j = i + 1; j < currentProcessedAvailableServices.length; j++) {
                  for (let k = j + 1; k < currentProcessedAvailableServices.length; k++) {
                      const s1 = currentProcessedAvailableServices[i];
                      const s2 = currentProcessedAvailableServices[j];
                      const s3 = currentProcessedAvailableServices[k];
                      const servicesInBundle = [s1,s2,s3];
                      let additionalCost = 0;
                      if (!s1.isSubscribed) additionalCost += s1.numericPrice;
                      if (!s2.isSubscribed) additionalCost += s2.numericPrice;
                      if (!s3.isSubscribed) additionalCost += s3.numericPrice;
                       allCandidateItems.push({
                          idSuffix: `triplet_${s1.id}_${s2.id}_${s3.id}`, servicesInvolved: servicesInBundle, additionalNumericCost: additionalCost
                       });
                  }
              }
          }
      }

      const uniqueCandidateItems = [];
      const seenBundleIds = new Set();
      allCandidateItems.forEach(bundleProto => {
          const uniqueServicesInBundle = [];
          const seenServiceIdsInCurrentBundle = new Set();
          bundleProto.servicesInvolved.forEach(s => {
              if(!seenServiceIdsInCurrentBundle.has(s.id)){
                  const fullService = currentProcessedAvailableServices.find(cps => cps.id === s.id);
                  if (fullService) uniqueServicesInBundle.push(fullService);
                  seenServiceIdsInCurrentBundle.add(s.id);
              }
          });
          bundleProto.servicesInvolved = uniqueServicesInBundle;
          if (bundleProto.idSuffix === 'empty_base_for_plus_logic' && bundleProto.servicesInvolved.length === 0) { /* allow */ }
          else if (bundleProto.servicesInvolved.length === 0 && bundleProto.idSuffix !== 'bundle_subscribed_only') return; // Skip if it became empty unless it's the specific "subscribed_only" placeholder for no subs

          const canonicalServiceIds = bundleProto.servicesInvolved.map(s => s.id).sort().join(',');
          const canonicalBundleId = `bundle_services:${canonicalServiceIds}`;

          if (!seenBundleIds.has(canonicalBundleId)) {
              const item = { ...bundleProto, id: canonicalBundleId, type: 'bundle' };
              const coverage = getBundleCoverageDetails(item.servicesInvolved, state.selectedLeagueIds, allLeaguesFlatForHelper);
              item.totalCoveredLeaguesCount = coverage.count;
              item.selectedLeaguesCoveredDetails = coverage.details;
              item.totalNumericPrice = item.servicesInvolved.reduce((sum, s) => sum + (s.numericPrice || 0), 0);
              item.newlyCoveredLeaguesDetails = {};
              Object.keys(coverage.details).forEach(leagueId => {
                const isNewServiceBundle = item.servicesInvolved.every(s => !userSubscribedServices.find(us => us.id === s.id));
                if (!baseCoveredLeagueIds.has(leagueId) || isNewServiceBundle) {
                  item.newlyCoveredLeaguesDetails[leagueId] = coverage.details[leagueId];
                }
              });
              if (item.servicesInvolved.length === 1) {
                  item.displayName = item.servicesInvolved[0].name;
              } else if (item.servicesInvolved.length > 1) {
                  item.displayName = item.servicesInvolved.map(s => s.name).join(' + ');
              } else {
                  item.displayName = (userSubscribedServices.length > 0 && item.id === `bundle_services:${userSubscribedServices.map(s=>s.id).sort().join(',')}`)
                                       ? "Your Current Subscriptions"
                                       : (item.servicesInvolved.length === 0 ? "No Services Required" : "Base Option");
              }
              item.valueScoreForAdditionalCost = item.additionalNumericCost > 0
                                ? item.totalCoveredLeaguesCount / item.additionalNumericCost
                                : (item.totalCoveredLeaguesCount > 0 ? Infinity : 0);
              item.valueScoreForTotalPrice = item.totalNumericPrice > 0
                                ? item.totalCoveredLeaguesCount / item.totalNumericPrice
                                : (item.totalCoveredLeaguesCount > 0 ? Infinity : 0);

              item.badge = null;
              item.redundantSubscriptions = [];
              item.potentialSavings = 0;
              if (item.totalCoveredLeaguesCount > 0 || item.id === `bundle_services:`) {
                 uniqueCandidateItems.push(item);
              }
              seenBundleIds.add(canonicalBundleId);
          }
      });
      allCandidateItems = uniqueCandidateItems.filter(item => item.totalCoveredLeaguesCount > 0 || item.servicesInvolved.length === 0); // Keep empty "subscribed_only" if it's the only one
      if (allCandidateItems.length === 0 && userSubscribedServices.length === 0) return []; // No options if no subs and no coverage
      if (allCandidateItems.length === 0 && userSubscribedServices.length > 0) { // If only "subscribed_only" remains and it has 0 coverage
          const subOnlyBundle = {
              id: `bundle_services:${userSubscribedServices.map(s => s.id).sort().join(',')}`,
              type: 'bundle', servicesInvolved: [...userSubscribedServices], additionalNumericCost: 0,
              totalCoveredLeaguesCount: 0, selectedLeaguesCoveredDetails: {},
              totalNumericPrice: userSubscribedServices.reduce((sum, s) => sum + (s.numericPrice || 0), 0),
              newlyCoveredLeaguesDetails: {}, displayName: "Your Current Subscriptions",
              valueScoreForAdditionalCost: 0, valueScoreForTotalPrice: 0,
              badge: null, redundantSubscriptions: [], potentialSavings: 0
          };
          allCandidateItems.push(subOnlyBundle);
      }


      // --- 1. Determine "Top Coverage Pick" ---
      const sortedForTopCoverage = [...allCandidateItems].sort((a, b) => {
        if (b.totalCoveredLeaguesCount !== a.totalCoveredLeaguesCount) return b.totalCoveredLeaguesCount - a.totalCoveredLeaguesCount;
        if (a.totalNumericPrice !== b.totalNumericPrice) return a.totalNumericPrice - b.totalNumericPrice;
        if (a.additionalNumericCost !== b.additionalNumericCost) return a.additionalNumericCost - b.additionalNumericCost;
        return a.servicesInvolved.length - b.servicesInvolved.length;
      });

      let topCoverageItem = null;
      if (sortedForTopCoverage.length > 0) { // No need for totalCoveredLeaguesCount > 0 here, as list is already filtered
        topCoverageItem = { ...sortedForTopCoverage[0], badge: 'Top Coverage' };
        if (topCoverageItem.servicesInvolved.length > 0) {
          const servicesInTopCoverageSet = new Set(topCoverageItem.servicesInvolved.map(s => s.id));
          userSubscribedServices.forEach(subscribedService => {
            if (!servicesInTopCoverageSet.has(subscribedService.id)) {
              topCoverageItem.redundantSubscriptions.push({
                id: subscribedService.id, name: subscribedService.name,
                price: subscribedService.price, numericPrice: subscribedService.numericPrice
              });
              topCoverageItem.potentialSavings += subscribedService.numericPrice;
            }
          });
        }
      }

      // --- 2. Determine "Best Value Pick" ---
      let bestValuePick = null;
      if (topCoverageItem) {
        // Pool for Best Value: items different from Top Coverage, must have some coverage
        const poolForBestValue = allCandidateItems.filter(item =>
          item.id !== topCoverageItem.id && item.totalCoveredLeaguesCount > 0
        );

        if (poolForBestValue.length > 0) {
          // Target coverage: one less than Top Coverage, but at least 1
          const targetCoverage = Math.max(1, topCoverageItem.totalCoveredLeaguesCount - 1);

          let candidatesAtTargetCoverage = poolForBestValue.filter(item => item.totalCoveredLeaguesCount === targetCoverage);

          if (candidatesAtTargetCoverage.length === 0 && targetCoverage > 1) {
            // If no items at X-1, try X-2, etc., or just take all items with less coverage than top pick.
            // For simplicity now, let's consider all items with less coverage than topCoverageItem,
            // or if topCoverageItem has max coverage, consider items with less than max.
            // A more robust way: find the highest coverage level available that is less than topCoverageItem's coverage.
            let maxCoverageBelowTop = 0;
            poolForBestValue.forEach(item => {
                if (item.totalCoveredLeaguesCount < topCoverageItem.totalCoveredLeaguesCount) {
                    maxCoverageBelowTop = Math.max(maxCoverageBelowTop, item.totalCoveredLeaguesCount);
                }
            });
            if (maxCoverageBelowTop > 0) {
                 candidatesAtTargetCoverage = poolForBestValue.filter(item => item.totalCoveredLeaguesCount === maxCoverageBelowTop);
            } else { // If all other options have same coverage as top, or 0, pick best value from those cheaper
                 candidatesAtTargetCoverage = poolForBestValue.filter(item => item.totalNumericPrice < topCoverageItem.totalNumericPrice);
            }
          }

          if (candidatesAtTargetCoverage.length > 0) {
            candidatesAtTargetCoverage.sort((a, b) => {
              // Primary: lowest totalNumericPrice
              if (a.totalNumericPrice !== b.totalNumericPrice) return a.totalNumericPrice - b.totalNumericPrice;
              // Secondary: lowest additionalNumericCost
              if (a.additionalNumericCost !== b.additionalNumericCost) return a.additionalNumericCost - b.additionalNumericCost;
              // Tertiary: fewer services
              return a.servicesInvolved.length - b.servicesInvolved.length;
            });
            bestValuePick = { ...candidatesAtTargetCoverage[0], badge: 'Best Value' };
          } else if (poolForBestValue.length > 0) {
            // Fallback if no items at X-1 coverage: sort all remaining by valueScoreForTotalPrice
            poolForBestValue.sort((a,b) => {
                if (b.valueScoreForTotalPrice !== a.valueScoreForTotalPrice) return b.valueScoreForTotalPrice - a.valueScoreForTotalPrice;
                if (b.totalCoveredLeaguesCount !== a.totalCoveredLeaguesCount) return b.totalCoveredLeaguesCount - a.totalCoveredLeaguesCount;
                return a.totalNumericPrice - b.totalNumericPrice;
            });
            bestValuePick = {...poolForBestValue[0], badge: 'Best Value'};
          }


          if (bestValuePick && bestValuePick.servicesInvolved.length > 0) {
              const servicesInValueBundleSet = new Set(bestValuePick.servicesInvolved.map(s => s.id));
              bestValuePick.redundantSubscriptions = [];
              bestValuePick.potentialSavings = 0;
              userSubscribedServices.forEach(subscribedService => {
                  if (!servicesInValueBundleSet.has(subscribedService.id)) {
                      bestValuePick.redundantSubscriptions.push({
                          id: subscribedService.id, name: subscribedService.name,
                          price: subscribedService.price, numericPrice: subscribedService.numericPrice
                      });
                      bestValuePick.potentialSavings += subscribedService.numericPrice;
                  }
              });
          } else {
              bestValuePick = null;
          }
        }
      }

      const finalList = [];
      if (topCoverageItem) finalList.push(topCoverageItem);

      const addedToFinalListPrimaryIds = new Set();
      if(topCoverageItem) addedToFinalListPrimaryIds.add(topCoverageItem.id);

      if (bestValuePick && (!topCoverageItem || bestValuePick.id !== topCoverageItem.id)) {
        finalList.push(bestValuePick);
        addedToFinalListPrimaryIds.add(bestValuePick.id);
      }

      const servicesInFinalBadgedItems = new Set(finalList.flatMap(item => item.servicesInvolved.map(s => s.id)));

      currentProcessedAvailableServices
        .filter(service => !servicesInFinalBadgedItems.has(service.id))
        .map(service => {
            const coverage = getBundleCoverageDetails([service], state.selectedLeagueIds, allLeaguesFlatForHelper);
            if (coverage.count > 0) {
                const effectiveNumericPrice = service.isSubscribed ? 0 : service.numericPrice;
                return {
                    id: service.id, type: 'service', servicesInvolved: [service], displayName: service.name,
                    totalCoveredLeaguesCount: coverage.count, selectedLeaguesCoveredDetails: coverage.details,
                    additionalNumericCost: effectiveNumericPrice,
                    numericPrice: service.numericPrice, totalNumericPrice: service.numericPrice,
                    isSubscribed: service.isSubscribed,
                    valueScoreForAdditionalCost: effectiveNumericPrice > 0 ? coverage.count / effectiveNumericPrice : (coverage.count > 0 ? Infinity : 0),
                    valueScoreForTotalPrice: service.numericPrice > 0 ? coverage.count / service.numericPrice : (coverage.count > 0 ? Infinity : 0),
                    badge: null, notes: service.notes, link: service.link, originalService: service,
                    newlyCoveredLeaguesDetails: {},
                };
            }
            return null;
        })
        .filter(item => item !== null)
        .sort((a,b) => {
            if (a.isSubscribed && !b.isSubscribed) return -1;
            if (!a.isSubscribed && b.isSubscribed) return 1;
            if (b.totalCoveredLeaguesCount !== a.totalCoveredLeaguesCount) return b.totalCoveredLeaguesCount - a.totalCoveredLeaguesCount;
            return a.additionalNumericCost - b.additionalNumericCost;
        })
        .forEach(item => {
            if (!finalList.some(fi => fi.id === item.id)) {
                 finalList.push(item);
            }
        });
      return finalList;
    }
  },

  actions: {
    toggleLeagueSelection(leagueId) {
      const index = this.selectedLeagueIds.indexOf(leagueId);
      if (index > -1) this.selectedLeagueIds.splice(index, 1);
      else this.selectedLeagueIds.push(leagueId);
    },
    toggleServiceSubscription(serviceId) {
      const index = this.subscribedServiceIds.indexOf(serviceId);
      if (index > -1) this.subscribedServiceIds.splice(index, 1);
      else this.subscribedServiceIds.push(serviceId);
    },
    toggleCategoryExpansion(categoryName) {
      const index = this.expandedCategories.indexOf(categoryName);
      if (index > -1) this.expandedCategories.splice(index, 1);
      else this.expandedCategories.push(categoryName);
    },
    toggleServiceCategoryExpansion(categoryName) {
      const index = this.expandedServiceCategories.indexOf(categoryName);
      if (index > -1) {
        this.expandedServiceCategories.splice(index, 1);
      } else {
        this.expandedServiceCategories.push(categoryName);
      }
    },
    selectAllLeagues() {
      const allLeagueIds = this.allLeaguesFlat.map(league => league.id);
      this.selectedLeagueIds = [...new Set(allLeagueIds)];
    },
    unselectAllLeagues() {
      this.selectedLeagueIds = [];
    },
    selectAllServices() {
      const allServiceIds = this.processedAvailableServicesFlat.map(service => service.id);
      this.subscribedServiceIds = [...new Set(allServiceIds)];
    },
    unselectAllServices() {
      this.subscribedServiceIds = [];
    }
  },
});
